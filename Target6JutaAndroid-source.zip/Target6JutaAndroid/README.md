# Target 6 Juta - Android

Project Android native (Kotlin + Jetpack Compose) untuk pencatatan permainan.

## Fitur
- Target Rp6.000.000, reward Rp50.000 per catatan.
- Catat jam dan tanggal saat tombol ditekan.
- Statistik, progress, dan riwayat 5 catatan terbaru.
- Data tersimpan otomatis di SharedPreferences.
- Ekspor riwayat CSV.
- Reset dengan dialog konfirmasi.

## Membuat APK
1. Instal Android Studio versi terbaru.
2. Buka folder `Target6JutaAndroid` melalui Android Studio.
3. Tunggu Gradle Sync selesai (perlu internet untuk mengunduh dependensi).
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.example.target6juta`
Min Android: Android 6.0 (API 23)
