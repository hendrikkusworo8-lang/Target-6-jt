package com.example.target6juta

import android.os.Bundle
import android.content.Context
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val TARGET = 6_000_000
private const val REWARD = 50_000
private val Bg = Color(0xFF0B1020)
private val Card = Color(0xFF151E32)
private val Blue = Color(0xFF477BFF)
private val Muted = Color(0xFF9BA9C4)
private val White = Color(0xFFF4F7FF)
private data class Play(val stamp: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TargetApp(this) }
    }
}

@Composable
private fun TargetApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("target6", Context.MODE_PRIVATE) }
    val plays = remember {
        mutableStateListOf<Play>().apply {
            val arr = try { JSONArray(prefs.getString("plays", "[]")) } catch (_: Exception) { JSONArray() }
            for (i in 0 until arr.length()) {
                val t = arr.optLong(i, 0L)
                if (t > 0) add(Play(t))
            }
        }
    }
    fun persist() {
        val arr = JSONArray()
        plays.forEach { arr.put(it.stamp) }
        prefs.edit().putString("plays", arr.toString()).apply()
    }
    val total = plays.size * REWARD
    val progress = (total.toFloat() / TARGET).coerceIn(0f, 1f)
    val dateFmt = remember { SimpleDateFormat("dd MMM yyyy • HH:mm", Locale("id", "ID")) }
    var showReset by remember { mutableStateOf(false) }
    var showAll by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            val csv = buildString {
                append("No,Tanggal dan Jam,Hasil (Rp)\n")
                plays.forEachIndexed { i, p ->
                    append("${i + 1},\"${dateFmt.format(Date(p.stamp))}\",$REWARD\n")
                }
            }
            try {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(csv) }
                message = "Riwayat berhasil diekspor"
            } catch (_: Exception) { message = "Gagal menyimpan file" }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Blue,
        onBackground = White, onSurface = White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Blue.copy(alpha=.18f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.EmojiEvents, null, tint = Blue)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("TARGET 6 JUTA", fontWeight = FontWeight.Bold, color = White, fontSize = 19.sp)
                        Text("Pencatat permainan", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.Savings, null, tint = Blue, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.height(22.dp))
                CardBox {
                    Text("TARGET PENGUMPULAN", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Rp6.000.000", color = White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Rp50.000 setiap selesai main", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(17.dp))
                    LinearProgressIndicator(
                        progress = { progress }, modifier = Modifier.fillMaxWidth().height(9.dp),
                        color = Blue, trackColor = Color(0xFF293650)
                    )
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${(progress * 100).toInt()}% tercapai", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("${plays.size}/120 main", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(13.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("TOTAL UANG", "Rp${"%,d".format(Locale("id","ID"), total)}", Icons.Default.AccountBalanceWallet, Modifier.weight(1f))
                    StatCard("JUMLAH MAIN", "${plays.size} kali", Icons.Default.SportsEsports, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("SISA TARGET", "Rp${"%,d".format(Locale("id","ID"), (TARGET-total).coerceAtLeast(0))}", Icons.Default.Flag, Modifier.weight(1f))
                    StatCard("PER MAIN", "Rp50.000", Icons.Default.AddCircle, Modifier.weight(1f))
                }
                Spacer(Modifier.height(17.dp))
                CardBox {
                    Text("CATAT PERMAINAN", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Sudah selesai bermain?", color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Tekan tombol untuk mencatat jam dan menambah hasil.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            plays.add(Play(System.currentTimeMillis()))
                            persist()
                            message = "Main ke-${plays.size} berhasil dicatat!"
                        },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                    ) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(8.dp))
                        Text("CATAT SELESAI MAIN", fontWeight = FontWeight.Bold)
                    }
                    if (message.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(message, color = Blue, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(17.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Riwayat permainan", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("${plays.size} catatan", color = Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                CardBox {
                    val shown = if (showAll) plays.indices.reversed() else plays.indices.reversed().take(5)
                    if (plays.isEmpty()) {
                        Text("Belum ada permainan dicatat.", color = Muted, fontSize = 13.sp)
                    } else {
                        shown.forEach { index ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(32.dp).background(Blue.copy(alpha=.16f), CircleShape), contentAlignment = Alignment.Center) {
                                    Text("${index+1}", color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Main ke-${index+1}", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(dateFmt.format(Date(plays[index].stamp)), color = Muted, fontSize = 11.sp)
                                }
                                Text("+50 rb", color = Color(0xFF55D6A2), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            if (index != shown.last()) HorizontalDivider(color = Color(0xFF293650))
                        }
                        if (plays.size > 5) {
                            TextButton(onClick = { showAll = !showAll }) {
                                Text(if (showAll) "Tampilkan lebih sedikit" else "Lihat semua riwayat")
                            }
                        }
                    }
                }
                Spacer(Modifier.height(13.dp))
                OutlinedButton(
                    onClick = { exportLauncher.launch("riwayat-target-6-juta.csv") },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("Unduh riwayat CSV")
                }
                OutlinedButton(
                    onClick = { showReset = true },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF7777))
                ) {
                    Icon(Icons.Default.DeleteOutline, null); Spacer(Modifier.width(8.dp)); Text("Reset semua data")
                }
                Spacer(Modifier.height(20.dp))
                Text("Data tersimpan otomatis di perangkat ini.", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(15.dp))
            }
        }
    }
    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Reset semua data?") },
            text = { Text("Semua riwayat permainan dan total uang akan dihapus. Tindakan ini tidak bisa dibatalkan.") },
            confirmButton = {
                TextButton(onClick = {
                    plays.clear(); persist(); showReset = false; showAll = false
                    message = "Semua data berhasil direset."
                }) { Text("RESET", color = Color(0xFFFF7777)) }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Batal") } }
        )
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Card, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun StatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier, color = Card, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(13.dp)) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(19.dp))
            Spacer(Modifier.height(10.dp))
            Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(value, color = White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
